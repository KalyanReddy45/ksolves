from flask import Flask, jsonify
from flask_restful import Api, Resource
from flask_sqlalchemy import SQLAlchemy
from flask_cors import CORS

app = Flask(__name__)
api = Api(app)
db = SQLAlchemy(app)

CORS(app)

app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///virtual_classroom.db'

class Class(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100))
    units = db.relationship('Unit', backref='class')

class Unit(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100))
    class_id = db.Column(db.Integer, db.ForeignKey('class.id'))
    sessions = db.relationship('Session', backref='unit')

# ... other models for Session, Lecture, and Comment

class ClassResource(Resource):
    def get(self):
        classes = Class.query.all()
        return jsonify([class_.serialize() for class_ in classes])

# ... other resource classes for units, sessions, lectures, and comments

api.add_resource(ClassResource, '/api/classes')
# ... other resource registrations

if __name__ == '__main__':
    db.create_all()
    app.run(debug=True)
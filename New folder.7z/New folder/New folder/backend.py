from flask import Flask, jsonify
from flask_restful import Api, Resource
from flask_sqlalchemy import SQLAlchemy
from flask_cors import CORS

app = Flask(__name__)
api = Api(app)
db = SQLAlchemy(app)

CORS(app)

app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///event_management.db'

class Event(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100))
    date = db.Column(db.Date)
    location = db.Column(db.String(100))
    attendees = db.relationship('User', backref='events')

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100))
    email = db.Column(db.String(100))

# ... other models for RSVP and Reminder

class EventResource(Resource):
    def get(self):
        events = Event.query.all()
        return jsonify([event.serialize() for event in events])

    # ... other methods for creating, updating, deleting events

api.add_resource(EventResource, '/api/events')
# ... other resource registrations

if __name__ == '__main__':
    db.create_all()
    app.run(debug=True)
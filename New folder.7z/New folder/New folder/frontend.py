from flask import Flask, render_template, jsonify, request
from flask_react import React
import requests

app = Flask(__name__)
react = React(app)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/events')
def get_events():
    response = requests.get('http://localhost:5000/api/events')
    return jsonify(response.json())

# ... other API routes for creating, updating, deleting events, handling RSVPs, reminders, and attendees

react.register('App', './components/App.jsx')

if __name__ == '__main__':
    app.run(debug=True)